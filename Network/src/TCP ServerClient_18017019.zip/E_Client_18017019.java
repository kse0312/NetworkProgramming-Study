import java.io.*;
import java.net.Inet4Address;
import java.net.Socket;

public class E_Client_18017019 {
    Socket clientSocket;
    OutputStreamWriter out;
    BufferedReader in;
    public static void main(String[] args) {
        E_Client_18017019 main = new E_Client_18017019();
        main.serverConnection();
        main.sendMessage("C:/Users/user/Downloads/FileTest_picture.jpg");
    }
    public void serverConnection() {
        try {
            // clientSocket = new Socket("127.0.0.1", 3000);
            clientSocket = new Socket(Inet4Address.getByName("172.29.48.1"), 3001);
            out = new OutputStreamWriter(clientSocket.getOutputStream());
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendMessage(String message) {
        try {
            FileInputStream fin = new FileInputStream(message);
            int data = 0;
            do{
                data=fin.read();
                //System.out.println(data);
                out.write(data);
            }while(data!=-1);
            System.out.println("File Send Finish");
            String response = null;
            try {
                response = in.readLine();
                System.out.println(response);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
